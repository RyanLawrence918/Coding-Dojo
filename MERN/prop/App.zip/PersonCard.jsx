import React, { Component } from 'react';

//NEEDS THIS CODE^^^  import React, { Component } from 'react';

// class extends Component
class PersonCard extends Component{
    render(){
        return (        
            <div>
                <h3>{this.props.lastName}, {this.props.firstName}</h3>
                <h5>Age: {this.props.age}</h5>
                <h5>Hair Color: {this.props.hairColor}</h5>
            </div>)
    }
}


export default PersonCard

// <h3>{this.props.comedyLast}{this.props.comedyFirst}</h3>
// <h3></h3>
// <p>Age: {this.props.comedyLast}</p>
// <p>Hair Color: {}</p>
// <button>Birthday Button for Tom Segura</button>