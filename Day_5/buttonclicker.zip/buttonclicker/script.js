function turnOff(element) {
    element.innerText = "Logout";
}

function hide(element) {
    element.remove();
}

function display(element){
    console.log('This page says Ninja was liked')
}